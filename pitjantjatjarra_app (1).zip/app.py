
import streamlit as st
import pandas as pd
from PIL import Image
import random

# Load flashcard data
data = pd.read_csv("data/flashcards.csv")

# Select a random flashcard
card = data.sample().iloc[0]

# Display flashcard
st.title("Learn Pitjantjatjarra with Napaltjarri")
st.image(f"images/{card['image']}", caption=f"{card['word']} - {card['translation']}", use_column_width=True)
st.write(f"**Phrase:** {card['phrase']}")
st.write(f"**Translation:** {card['phrase_translation']}")

# Quiz interaction
user_input = st.text_input("Type the English translation of the word above:")

if user_input:
    if user_input.strip().lower() == card['translation'].lower():
        st.image("images/napaltjarri_happy.png")
        st.success("Great job!")
    else:
        st.image("images/napaltjarri_try_again.png")
        st.warning("Let's try again!")
